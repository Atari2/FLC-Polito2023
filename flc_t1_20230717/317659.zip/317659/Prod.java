class Prod {
    public Integer id;
    public String name;
    public Double price;
    public Prod(Integer id, String name, Double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
}